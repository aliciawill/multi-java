package 컬렉션복습;

public class 은행 {

	public static void main(String[] args) {
		계좌 account1 = new 계좌("홍길동", "정기적금", 1000);
		System.out.println(account1);
		계좌 account2 = new 계좌("김길동", "정기예금", 2000);
		System.out.println(account2);
		//계좌 account3 = new 계좌();
		
	}

}
